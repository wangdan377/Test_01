class oneDay(object):
    def __init__(self):
        self.name = 'lihua'
    def run(self):
        print('go go go')

# if __name__ == '__main__':
#     shili = oneDay()
#     shili.run()